// Prisca Ravoarrimanana - YouTube Downloader : serveur
const express = require('express');
const cors = require('cors');
const ytdl = require('@distube/ytdl-core');
const ffmpegPath = require('ffmpeg-static');
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors()); // autorise le Front-End à appeler l'API
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Utilitaires ----------
const cleanName = (s) =>
  (s || 'video').replace(/[\\/:*?"<>|]+/g, '').replace(/\s+/g, ' ').trim().slice(0, 100) || 'video';

const asciiName = (s) => s.replace(/[^\x20-\x7E]/g, '').trim() || 'video';

// Valide l'URL avant tout traitement
function validateUrl(req, res, next) {
  const url = req.query.url;
  if (!url || typeof url !== 'string' || !ytdl.validateURL(url.trim())) {
    return res.status(400).json({
      error: "Lien invalide. Colle l'adresse complète d'une vidéo YouTube (youtube.com/watch?v=… ou youtu.be/…).",
    });
  }
  req.videoUrl = url.trim();
  next();
}

function explainError(err) {
  const m = String(err && err.message || err);
  if (/private/i.test(m)) return 'Cette vidéo est privée.';
  if (/age/i.test(m)) return 'Cette vidéo est soumise à une restriction d\'âge.';
  if (/unavailable|not available|removed/i.test(m)) return "Cette vidéo n'est pas disponible.";
  if (/Sign in|bot|429|403/i.test(m))
    return 'YouTube a refusé la requête. Réessaie dans quelques minutes ou mets à jour la bibliothèque (npm update @distube/ytdl-core).';
  return 'Impossible de lire cette vidéo pour le moment.';
}

// ---------- GET /api/info : aperçu + validation ----------
app.get('/api/info', validateUrl, async (req, res) => {
  try {
    const info = await ytdl.getBasicInfo(req.videoUrl);
    const d = info.videoDetails;
    res.json({
      title: d.title,
      author: d.author && d.author.name,
      seconds: Number(d.lengthSeconds),
      thumbnail: d.thumbnails[d.thumbnails.length - 1].url,
    });
  } catch (err) {
    console.error('info:', err.message);
    res.status(502).json({ error: explainError(err) });
  }
});

// ---------- GET /api/download : flux MP4 meilleure qualité ----------
app.get('/api/download', validateUrl, async (req, res) => {
  let info;
  try {
    info = await ytdl.getInfo(req.videoUrl);
  } catch (err) {
    console.error('getInfo:', err.message);
    return res.status(502).json({ error: explainError(err) });
  }

  const title = cleanName(info.videoDetails.title);
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="${asciiName(title)}.mp4"; filename*=UTF-8''${encodeURIComponent(title)}.mp4`
  );
  res.setHeader('Content-Type', 'video/mp4');

  const streams = [];
  const cleanup = () => {
    streams.forEach((s) => s.destroy && s.destroy());
  };
  res.on('close', cleanup);

  const fail = (err) => {
    console.error('download:', err && err.message);
    cleanup();
    if (!res.headersSent) res.status(500).json({ error: explainError(err) });
    else res.end();
  };

  try {
    // Meilleure vidéo MP4 (sans audio) + meilleur audio MP4, fusionnés à la volée par ffmpeg
    const videoFormat = ytdl.chooseFormat(info.formats, {
      quality: 'highestvideo',
      filter: (f) => f.container === 'mp4' && f.hasVideo && !f.hasAudio,
    });
    const audioFormat = ytdl.chooseFormat(info.formats, {
      quality: 'highestaudio',
      filter: (f) => f.container === 'mp4' && f.hasAudio && !f.hasVideo,
    });

    const ff = spawn(
      ffmpegPath,
      [
        '-loglevel', 'error',
        '-i', 'pipe:3',
        '-i', 'pipe:4',
        '-map', '0:v',
        '-map', '1:a',
        '-c', 'copy',
        '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
        '-f', 'mp4',
        'pipe:1',
      ],
      { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe', 'pipe', 'pipe'] }
    );
    streams.push({ destroy: () => ff.kill('SIGKILL') });

    const video = ytdl.downloadFromInfo(info, { format: videoFormat });
    const audio = ytdl.downloadFromInfo(info, { format: audioFormat });
    streams.push(video, audio);

    video.on('error', fail);
    audio.on('error', fail);
    ff.on('error', fail);
    ff.stderr.on('data', (d) => console.error('ffmpeg:', d.toString()));
    ff.stdio[3].on('error', () => {});
    ff.stdio[4].on('error', () => {});

    video.pipe(ff.stdio[3]);
    audio.pipe(ff.stdio[4]);
    ff.stdout.pipe(res);
  } catch (err) {
    // Repli : format MP4 unique (audio + vidéo), qualité plus basse mais fiable
    try {
      const format = ytdl.chooseFormat(info.formats, {
        quality: 'highest',
        filter: (f) => f.container === 'mp4' && f.hasVideo && f.hasAudio,
      });
      const stream = ytdl.downloadFromInfo(info, { format });
      streams.push(stream);
      stream.on('error', fail);
      stream.pipe(res);
    } catch (e) {
      fail(e);
    }
  }
});

// ---------- Démarrage ----------
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\nPrisca Ravoarrimanana - YouTube Downloader`);
  console.log(`PC      : http://localhost:${PORT}`);
  Object.values(os.networkInterfaces())
    .flat()
    .filter((n) => n.family === 'IPv4' && !n.internal)
    .forEach((n) => console.log(`iPhone  : http://${n.address}:${PORT}`));
  console.log('');
});
